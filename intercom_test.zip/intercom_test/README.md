# Smart Indoor Intercom — Laptop Client

A desktop **video door-intercom** client. When the door station calls, the app shows live
video (even while ringing), lets you **Accept** with **two-way audio**, **Unlock** the door,
**Mute** your mic, and **End** the call. Works with a Tuya-based IP door station over the LAN
using its native call protocol — no cloud, no vendor app.

For protocol details and integration into another app, see
**TECHNICAL_DOCUMENTATION.md**.

---

## Requirements

- **Python 3.10+**
- **ffmpeg** installed and on your PATH (`ffmpeg -version` should work). If it isn't on PATH,
  edit `FFMPEG_PATH` near the top of `intercom_app.py`.
- Python packages:
  ```
  pip install PySide6 numpy opencv-python sounddevice
  ```
- On **Python 3.13+** also install the G.711 helper (the stdlib `audioop` was removed):
  ```
  pip install audioop-lts
  ```

The laptop and the door must be on the **same local network**.

## Run

```
python intercom_app.py
```

A window opens and starts listening. The log panel shows the discovery replies and the IP/ports
it's using. When the door calls:

- **Video appears while it's still ringing.**
- **Accept** — connects two-way audio (you hear the visitor; they hear you).
- **Unlock** — sends the door-release command (see note below).
- **Mute** — silences your microphone; press again to unmute.
- **End** — hangs up and closes the call.

Allow microphone access if Windows prompts.

## Network ports

| Port | Proto | Purpose |
|------|-------|---------|
| 8089 | UDP   | Discovery — the door finds this unit |
| 8189 | TCP   | The call — control, video, and audio |

Allow Python through the firewall on both. Don't expose these ports to the internet; the protocol
has no authentication or encryption and is meant for a trusted LAN.

## Audio tuning

If your voice at the door is too quiet or distorted, adjust two values at the top of the
`AudioWorker` class:

- `GAIN` (default `4.0`) — microphone loudness. Raise to `6`–`8` if you're too quiet; lower if loud
  words crackle.
- `GATE` (default `300`) — noise gate. If the **start of your words gets cut off**, lower to ~`150`.
  If you hear background noise or feedback when silent, raise it.

Audio is **G.711 A-law at 8 kHz** (telephone quality) by design — it won't sound like a wideband
call. The app has **no echo cancellation**, so for hands-free use either keep the other person's
volume modest, use the **Mute** button while listening, or plug in **headphones/earbuds** (this
removes echo entirely).

## Unlock button

The exact door-release command for this device hasn't been confirmed yet. The **Unlock cmd**
dropdown holds likely candidates plus a free-text box. Pick one, press **Unlock**, and watch the
log for the door's reply. The reliable way to find the real one: press unlock on the **original
indoor panel** during a call and observe the command it sends, then put that in the dropdown (or
set it as the default in `UNLOCK_CANDIDATES`).

## How it works (one paragraph)

The door announces calls over UDP 8089; the app replies with its identity so the door knows an
indoor unit is present. The call itself runs over a single TCP 8189 connection carrying three kinds
of length-prefixed frames, told apart by a 4-byte tag: control commands (JSON), H.264 video, and
G.711 A-law audio. The app shows the video, plays the audio, sends your microphone back the same
way, and replies to the door's call/answer/hang-up commands. Full details are in
**TECHNICAL_DOCUMENTATION.md**.

## Troubleshooting

- **No video** — confirm `ffmpeg -version` runs. Don't add `-fflags nobuffer` to the decoder; it
  silently breaks piped H.264.
- **Door never rings** — allow UDP 8089 / TCP 8189 through the firewall; confirm both devices are on
  the same subnet; check the log for a discovery reply.
- **`ModuleNotFoundError: audioop`** (Python 3.13+) — `pip install audioop-lts`.
- **They can't hear me** — make sure the call is connected (the app sends `StartTalk` on accept,
  which opens the door's speaker); check the log for `[SEND audio]` lines.
- **Indentation errors after editing** — use spaces, not tabs (VS Code: "Convert Indentation to
  Spaces", indent size 4).

## Files

- `intercom_app.py` — the application.
- `TECHNICAL_DOCUMENTATION.md` — protocol spec, code walkthrough, integration guide.
- `README.md` — this file.
