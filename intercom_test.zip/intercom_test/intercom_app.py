"""
intercom_app.py
====================================================================
Smart Indoor Intercom — laptop receiver (PySide6)

Ported from the working tkinter demo. Same proven protocol, but:
  * the door VIDEO renders INSIDE the app window (no separate ffplay popup)
  * your REAL microphone is captured with a live level meter (+ a
    configurable uplink hook to send mic -> door once you know its audio port)
  * an UNLOCK DOOR button that tries a chosen command and logs the reply
  * a live LOG panel showing discovery / TCP / commands / video status

PROTOCOL (unchanged, from your demo):
  UDP 8089 = discovery. Door asks "cmd_send_get_call_device" /
             "cmd_send_get_device_info"; we reply with SCREEN_INFO.
  TCP 8189 = call. "$"+JSON messages. {"command":"Call"} rings us.
             We send Answer; then the SAME socket streams raw H.264,
             which we decode to frames and show in the window.
             Reject/End sends HangUp.

Run:  python intercom_app.py
Needs: pip install PySide6 numpy opencv-python sounddevice   (+ ffmpeg on PATH)
====================================================================
"""

import sys
import os
import json
import time
import socket
import struct
import audioop  # G.711 mu-law <-> PCM (Python standard library, 3.12 and earlier)
import shutil
import threading
import subprocess
import winsound

import numpy as np

# ----------------------------------------------------------------- config ---
UDP_PORT = 8089
TCP_PORT = 8189

# Path to ffmpeg. We try the system one first, then your Windows download path.
FFMPEG_PATH = shutil.which("ffmpeg") or r"C:\Users\s\Downloads\ffmpeg\ff\bin\ffmpeg.exe"

VIDEO_W, VIDEO_H = 640, 480          # door video is scaled to this for display
SELF_CAM_INDEX = 0                   # your laptop webcam (self-view PiP)

# This is the identity your laptop announces to the door station.
SCREEN_INFO = {
    "command": "cmd_reply_get_device_info",
    "appid": "7551000",
    "alias": "Laptop Indoor",
    "group_ip": "239.255.74.199",
    "serial": "LAPTOP001",
    "dstType": 3,
    "dstAddr": "999-000-1",
    "verify": 0,
    "deviceBusy": 0,
    "camera_en": 0,
    "relay0_delay": 1,
}

# Candidate UNLOCK commands to TRY (your device's exact one is still unknown).
# Pick one in the UI or type your own; the log shows what the door replies.
UNLOCK_CANDIDATES = [
    '{"command":"OpenDoor"}',
    '{"command":"OpenDoor","relay":0}',
    '{"command":"Unlock"}',
    '{"command":"OpenLock","dstAddr":"999-000-1"}',
    '{"command":"cmd_open_door","relay0_delay":1}',
]

TALK_CANDIDATES = [
    '{"command":"StartTalk"}',
    '{"command":"OpenTalk"}',
    '{"command":"Talk"}',
    '{"command":"StartVoice"}',
    '{"command":"AudioStart"}',
    '{"command":"StartAudio"}',
    '{"command":"OpenAudio"}',
    '{"command":"StartTalkback"}',
    '{"command":"Monitor"}',
    '{"command":"StartTalk","OtherAnswer":1}',
]

# Mic uplink to the door: OFF until you know the door's audio port + format.
# When you find it, set host/port; raw 16-bit PCM @ 8kHz is a common guess.
AUDIO_UPLINK_HOST = None
AUDIO_UPLINK_PORT = None
AUDIO_RATE = 8000
# ---------------------------------------------------------------------------

try:
    import cv2
    HAVE_CV2 = True
except Exception:
    HAVE_CV2 = False

try:
    import sounddevice as sd
    HAVE_AUDIO = True
except Exception:
    HAVE_AUDIO = False

from PySide6.QtCore import Qt, QTimer, Signal, QObject, QThread
from PySide6.QtGui import QImage, QPixmap, QFont
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton, QComboBox,
    QVBoxLayout, QHBoxLayout, QFrame, QProgressBar, QPlainTextEdit, QSizePolicy
)


# ===========================================================================
#  UDP discovery: reply to the door so it knows this laptop is an indoor unit
# ===========================================================================
class DiscoveryListener(QObject):
    log = Signal(str)

    def __init__(self):
        super().__init__()
        self._running = True

    def start(self):
        threading.Thread(target=self._serve, daemon=True).start()

    def _serve(self):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("0.0.0.0", UDP_PORT))
        except Exception as e:
            self.log.emit(f"[UDP] cannot bind {UDP_PORT}: {e}")
            return
        self.log.emit(f"[UDP] discovery listening on {UDP_PORT}")
        while self._running:
            try:
                data, addr = sock.recvfrom(8192)
                text = data.decode(errors="ignore")
                if ("cmd_send_get_call_device" in text
                        or "cmd_send_get_device_info" in text):
                    reply = json.dumps(SCREEN_INFO, separators=(",", ":"))
                    sock.sendto(reply.encode(), (addr[0], UDP_PORT))
                    self.log.emit(f"[UDP] discovery from {addr[0]} -> replied SCREEN_INFO")
            except Exception as e:
                self.log.emit(f"[UDP] error: {e}")

    def stop(self):
        self._running = False


# ===========================================================================
#  H.264 decoder: feed raw stream bytes, get QImage frames (rendered in-window)
# ===========================================================================
class VideoDecoder(QThread):
    frame = Signal(QImage)
    log = Signal(str)

    def __init__(self):
        super().__init__()
        self.proc = None
        self._lock = threading.Lock()
        self._running = False

    def start_decoder(self):
        if self.proc:
            return
        cmd = [
            FFMPEG_PATH, "-loglevel", "quiet",
            "-flags", "low_delay",
            "-f", "h264", "-i", "pipe:0",
            "-vf", f"scale={VIDEO_W}:{VIDEO_H}",
            "-pix_fmt", "rgb24", "-f", "rawvideo", "pipe:1",
        ]
        try:
            self.proc = subprocess.Popen(
                cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL, bufsize=0)
        except Exception as e:
            self.log.emit(f"[VIDEO] could not start ffmpeg: {e}")
            return
        self._running = True
        self.start()
        self.log.emit("[VIDEO] decoder started")

    def feed(self, data: bytes):
        with self._lock:
            if self.proc and self.proc.stdin:
                try:
                    self.proc.stdin.write(data)
                    self.proc.stdin.flush()
                except Exception:
                    pass

    def run(self):
        frame_bytes = VIDEO_W * VIDEO_H * 3
        buf = b""
        while self._running and self.proc and self.proc.stdout:
            try:
                chunk = self.proc.stdout.read(frame_bytes - len(buf))
            except Exception:
                break
            if not chunk:
                break
            buf += chunk
            if len(buf) >= frame_bytes:
                arr = np.frombuffer(buf[:frame_bytes], dtype=np.uint8)
                img = QImage(arr.tobytes(), VIDEO_W, VIDEO_H,
                             3 * VIDEO_W, QImage.Format_RGB888)
                self.frame.emit(img.copy())
                buf = buf[frame_bytes:]

    def stop_decoder(self):
        self._running = False
        if self.proc:
            try:
                self.proc.kill()
            except Exception:
                pass
        self.proc = None
        self.wait(500)


# ===========================================================================
#  TCP call server: handles the call signalling + receives the video stream
# ===========================================================================
class CallServer(QObject):
    incoming = Signal(str)
    remote_hangup = Signal()
    video = Signal(bytes)
    audio = Signal(bytes)
    closed = Signal()
    log = Signal(str)

    MAGIC_CTRL = b"\xaa\xaa\xaa\xaa"
    MAGIC_MEDIA = b"\xbb\xbb\xbb\xbb"
    MAGIC_AUDIO = b"\xcc\xcc\xcc\xcc"

    def __init__(self):
        super().__init__()
        self.conn = None
        self.call_active = False
        self.ringing = False
        self._running = True
        self._peer = ""

    def start(self):
        threading.Thread(target=self._serve, daemon=True).start()

    def _serve(self):
        try:
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind(("0.0.0.0", TCP_PORT))
            srv.listen(10)
        except Exception as e:
            self.log.emit(f"[TCP] cannot bind {TCP_PORT}: {e}")
            return
        self.log.emit(f"[TCP] call server listening on {TCP_PORT}")
        while self._running:
            try:
                conn, addr = srv.accept()
            except OSError:
                break
            threading.Thread(target=self._handle, args=(conn, addr),
                             daemon=True).start()

    def _handle(self, conn, addr):
        self.conn = conn
        self.call_active = False
        self._peer = addr[0]
        self.log.emit(f"[TCP] connected {addr}")
        buf = b""
        try:
            while True:
                data = conn.recv(65536)
                if not data:
                    break
                buf += data
                buf = self._parse(buf)
        except Exception as e:
            self.log.emit(f"[TCP] error: {e}")
        finally:
            try:
                conn.close()
            except Exception:
                pass
            self.call_active = False
            self.conn = None
            self.closed.emit()
            self.log.emit("[TCP] closed")

    def _parse(self, buf):
        # frame format:  <4-byte magic> <4-byte little-endian length> <payload>
        while len(buf) >= 8:
            magic = buf[:4]
            if magic in (self.MAGIC_CTRL, self.MAGIC_MEDIA, self.MAGIC_AUDIO):
                length = struct.unpack("<I", buf[4:8])[0]
                if length > 20_000_000:        # sanity guard against bad sync
                    buf = self._resync(buf)
                    continue
                if len(buf) < 8 + length:
                    break                      # wait for the rest of this frame
                payload = buf[8:8 + length]
                buf = buf[8 + length:]
                if magic == self.MAGIC_CTRL:
                    self._on_control(payload)
                elif magic == self.MAGIC_AUDIO:
                    if self.call_active:
                        self.audio.emit(payload)   # 160-byte G.711 mu-law
                else:
                    if self.call_active or self.ringing:
                        self.video.emit(payload)   # clean H.264, no headers
            else:
                buf = self._resync(buf)
        return buf

    def _resync(self, buf):
        a = buf.find(self.MAGIC_CTRL, 1)
        b = buf.find(self.MAGIC_MEDIA, 1)
        idxs = [i for i in (a, b) if i != -1]
        if not idxs:
            return buf[-3:]            # keep tail in case a magic is split
        return buf[min(idxs):]

    def _on_control(self, payload):
        text = payload.decode(errors="ignore")
        self.log.emit(f"[CTRL] {text[:200]}")
        if '"Call"' in text:
            self.ringing = True
            self.incoming.emit(self._peer)
        elif '"HangUp"' in text:
            self.remote_hangup.emit()
        elif '"GetCallInfo"' in text:
            if self.call_active:
                self.answer()    # re-confirm answer when device asks again

    def _frame(self, json_str):
        body = json_str.encode()
        return self.MAGIC_CTRL + struct.pack("<I", len(body)) + body

    def send(self, raw, note=""):
        if not self.conn:
            self.log.emit("[SEND] no connection")
            return
        try:
            self.conn.sendall(raw)
            self.log.emit(f"[SEND]{(' ' + note) if note else ''} {len(raw)}B")
        except Exception as e:
            self.log.emit(f"[SEND] error: {e}")

    def answer(self):
        for j in ('{"command":"Answer"}',
                  '{"command":"Answer","OtherAnswer":1}',
                  '{"command":"Answer","OtherAnswer":true}'):
            self.send(self._frame(j), "answer")
            time.sleep(0.08)
        self.call_active = True
        self._audio_sent = 0

    def send_audio(self, mulaw_bytes):
        if self.conn and self.call_active:
            try:
                self.conn.sendall(self.MAGIC_AUDIO + struct.pack("<I", len(mulaw_bytes)) + mulaw_bytes)
                self._audio_sent += 1
                if self._audio_sent % 50 == 1:
                    self.log.emit(f"[SEND audio] frame {self._audio_sent}, {len(mulaw_bytes)}B")
            except Exception as e:
                self.log.emit(f"[SEND audio] error: {e}")

    def send_talk(self, json_str):
        self.send(self._frame(json_str), "talk-try")

    def hangup(self):
        self.send(self._frame('{"command":"HangUp","OtherAnswer":0}'), "hangup")
        self.call_active = False
        time.sleep(0.15)
        if self.conn:
            try:
                self.conn.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                self.conn.close()
            except Exception:
                pass
            self.conn = None

    def stop(self):
        self._running = False


# ===========================================================================
#  Microphone: real capture + live level. Optional UDP uplink to the door.
# ===========================================================================
class AudioWorker(QThread):
    level = Signal(int)
    log = Signal(str)

    _INV = bytes(x ^ 0xFF for x in range(256))   # fast mu-law byte inversion

    GAIN = 4.0      # mic boost (raise if quiet, lower if distorted)
    GATE = 300      # mic noise gate: below this RMS, send silence (breaks echo loop)
    MAX_PLAY = 6400 # playback latency cap in bytes (~0.4s @ 8kHz/16bit)

    def __init__(self, call_server):
        super().__init__()
        self._running = False
        self.server = call_server
        self._play_buf = b""
        self._play_lock = threading.Lock()
        self._muted = False

    def set_muted(self, m):
        self._muted = bool(m)

    def play(self, mulaw):
        try:
            pcm = audioop.alaw2lin(mulaw, 2)
            with self._play_lock:
                self._play_buf += pcm
                if len(self._play_buf) > self.MAX_PLAY:    # drop stale audio -> low latency
                    self._play_buf = self._play_buf[-self.MAX_PLAY:]
        except Exception:
            pass

    def run(self):
        if not HAVE_AUDIO:
            self.log.emit("[AUDIO] sounddevice not available")
            return
        self._running = True
        try:
            def out_cb(outdata, frames, t, status):
                need = frames * 2
                with self._play_lock:
                    chunk = self._play_buf[:need]
                    self._play_buf = self._play_buf[need:]
                if len(chunk) < need:
                    chunk += b"\x00" * (need - len(chunk))
                outdata[:] = np.frombuffer(chunk, dtype=np.int16).reshape(-1, 1)

            out = sd.OutputStream(samplerate=8000, channels=1, dtype="int16",
                                  blocksize=160, callback=out_cb)
            out.start()
            self.log.emit("[AUDIO] speaker live")

            with sd.InputStream(channels=1, samplerate=8000, dtype="int16",
                                blocksize=160) as mic:
                self.log.emit("[AUDIO] microphone live")
                while self._running:
                    block, _ = mic.read(160)
                    block = block.reshape(-1)
                    rms = float(np.sqrt(np.mean(block.astype(np.float32) ** 2)))
                    self.level.emit(min(100, int(rms / 200)))

                    if self._muted or rms < self.GATE:
                        out_block = np.zeros(160, dtype=np.int16)   # silence
                    else:
                        x = block.astype(np.float32) * self.GAIN
                        np.clip(x, -32768, 32767, out=x)            # clip only true overshoots
                        out_block = x.astype(np.int16)

                    mulaw = audioop.lin2alaw(out_block.tobytes(), 2)
                    self.server.send_audio(mulaw)
            out.stop(); out.close()
        except Exception as e:
            self.log.emit(f"[AUDIO] error: {e}")

    def stop(self):
        self._running = False
        self.wait(500)

# ===========================================================================
#  Main window
# ===========================================================================
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Smart Indoor Intercom")
        self.resize(760, 760)
        self.setStyleSheet("background:#11151c;color:#e8edf2;")

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(10)

        title = QLabel("🔔  Smart Indoor Intercom")
        title.setFont(QFont("Arial", 18, QFont.Bold))
        root.addWidget(title)

        self.status = QLabel("Waiting for intercom call…")
        self.status.setStyleSheet("color:#9fb3c8;")
        root.addWidget(self.status)

        # ---- video area with self-view PiP -------------------------------
        vframe = QFrame()
        vframe.setStyleSheet("background:#000;border-radius:10px;")
        vframe.setMinimumHeight(380)
        vlay = QVBoxLayout(vframe)
        vlay.setContentsMargins(0, 0, 0, 0)
        self.video = QLabel("DOOR CAMERA")
        self.video.setAlignment(Qt.AlignCenter)
        self.video.setStyleSheet("color:#555;")
        self.video.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        vlay.addWidget(self.video)
        self.self_view = QLabel(self.video)
        self.self_view.setFixedSize(160, 120)
        self.self_view.move(580, 250)
        self.self_view.setStyleSheet("border:2px solid #2b3a4a;")
        self.self_view.hide()
        root.addWidget(vframe, stretch=1)

        # ---- mic meter ---------------------------------------------------
        mrow = QHBoxLayout()
        mrow.addWidget(QLabel("🎤 Mic"))
        self.mic_bar = QProgressBar()
        self.mic_bar.setRange(0, 100)
        self.mic_bar.setTextVisible(False)
        self.mic_bar.setFixedHeight(14)
        self.mic_bar.setStyleSheet(
            "QProgressBar{background:#1c2530;border-radius:7px;}"
            "QProgressBar::chunk{background:#3ddc84;border-radius:7px;}")
        mrow.addWidget(self.mic_bar)
        root.addLayout(mrow)

        # ---- unlock command selector ------------------------------------
        urow = QHBoxLayout()
        urow.addWidget(QLabel("Unlock cmd:"))
        self.unlock_combo = QComboBox()
        self.unlock_combo.setEditable(True)
        self.unlock_combo.addItems(UNLOCK_CANDIDATES)
        self.unlock_combo.setStyleSheet("background:#1c2530;padding:4px;")
        urow.addWidget(self.unlock_combo, stretch=1)
        root.addLayout(urow)

        trow = QHBoxLayout()
        trow.addWidget(QLabel("Talk cmd:"))
        self.talk_combo = QComboBox()
        self.talk_combo.setEditable(True)
        self.talk_combo.addItems(TALK_CANDIDATES)
        self.talk_combo.setStyleSheet("background:#1c2530;padding:4px;")
        trow.addWidget(self.talk_combo, stretch=1)
        self.talk_btn = QPushButton("🔊 Send talk cmd")
        self.talk_btn.clicked.connect(self.try_talk)
        trow.addWidget(self.talk_btn)
        root.addLayout(trow)

        # ---- buttons -----------------------------------------------------
        brow = QHBoxLayout()
        self.answer_btn = self._btn("✅ Accept", "#2e7d32", self.accept_call)
        self.unlock_btn = self._btn("🔓 Unlock", "#1565c0", self.unlock)
        self.reject_btn = self._btn("❌ End", "#c62828", self.reject_call)
        self.unlock_btn.setEnabled(False)
        self.answer_btn.setEnabled(False)
        self.reject_btn.setEnabled(False)
        self.mute_btn = self._btn("🔇 Mute", "#5a3a00", self.toggle_mute)
        for b in (self.answer_btn, self.unlock_btn, self.mute_btn, self.reject_btn):
            brow.addWidget(b)
        root.addLayout(brow)

        # ---- log panel ---------------------------------------------------
        self.logbox = QPlainTextEdit()
        self.logbox.setReadOnly(True)
        self.logbox.setFixedHeight(150)
        self.logbox.setStyleSheet(
            "background:#0c0f14;color:#7fe3a0;font-family:monospace;font-size:11px;")
        root.addWidget(self.logbox)

        # ---- workers -----------------------------------------------------
        self.decoder = VideoDecoder()
        self.decoder.frame.connect(self._show_frame)
        self.decoder.log.connect(self.log)


        self.discovery = DiscoveryListener()
        self.discovery.log.connect(self.log)
        self.discovery.start()

        self.server = CallServer()
        self.server.incoming.connect(self.on_incoming)
        self.server.remote_hangup.connect(self.on_remote_hangup)
        self.server.video.connect(self.decoder.feed)
        self.server.closed.connect(self.on_closed)
        self.server.log.connect(self.log)
        self.server.start()
        self.mic = AudioWorker(self.server)
        self.mic.level.connect(self.mic_bar.setValue)
        self.mic.log.connect(self.log)
        self.server.audio.connect(self.mic.play)

        # self-view webcam timer
        self.self_cam = None   # camera disabled: video is one-way (door -> laptop only)
        self.self_timer = QTimer(self)
        self.self_timer.timeout.connect(self._update_self_view)

        self.log(f"[INFO] ffmpeg: {FFMPEG_PATH}")
        self.log(f"[INFO] webcam: {'yes' if self.self_cam else 'no'}  "
                 f"mic: {'yes' if HAVE_AUDIO else 'no'}")
        self.log(f"[INFO] my IP: {self._my_ip()}  UDP {UDP_PORT} / TCP {TCP_PORT}")

    # ---- helpers ----
    def _btn(self, text, color, slot):
        b = QPushButton(text)
        b.setMinimumHeight(46)
        b.setCursor(Qt.PointingHandCursor)
        b.clicked.connect(slot)
        b.setStyleSheet(
            f"QPushButton{{background:{color};color:white;border:none;"
            f"border-radius:10px;font-size:15px;font-weight:bold;}}"
            f"QPushButton:disabled{{background:#33414f;color:#7d8a97;}}")
        return b

    def _my_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def log(self, msg):
        self.logbox.appendPlainText(msg)

    # ---- video display ----
    def _show_frame(self, img):
        self.video.setPixmap(QPixmap.fromImage(img).scaled(
            self.video.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def _update_self_view(self):
        if self.self_cam:
            ok, frame = self.self_cam.read()
            if ok:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frame = cv2.resize(frame, (160, 120))
                img = QImage(frame.data, 160, 120, 3 * 160, QImage.Format_RGB888)
                self.self_view.setPixmap(QPixmap.fromImage(img.copy()))

    # ---- call events ----
    def _start_ring(self):
        try:
            # loops a system sound until stopped; async so the UI stays responsive
            winsound.PlaySound("SystemAsterisk",
                               winsound.SND_ALIAS | winsound.SND_ASYNC | winsound.SND_LOOP)
        except Exception as e:
            self.log(f"[RING] could not play ringtone: {e}")

    def _stop_ring(self):
        try:
            winsound.PlaySound(None, winsound.SND_PURGE)   # stop any looping sound
        except Exception:
            pass

    def on_incoming(self, ip):
        self.status.setText(f"Incoming call from {ip}")
        self.answer_btn.setEnabled(True)
        self.reject_btn.setEnabled(True)
        self.decoder.start_decoder()   # show door video while ringing, before Accept
        self._start_ring()
        self.raise_()
        self.activateWindow()
        self.setWindowState(self.windowState() & ~Qt.WindowMinimized | Qt.WindowActive)

    def accept_call(self):
        self._stop_ring()
        self.server.answer()
        self.decoder.start_decoder()
        self.mic.start()
        self.self_timer.start(40)
        self.status.setText("Connected — video loading…")
        self.answer_btn.setEnabled(False)
        self.unlock_btn.setEnabled(True)

    def unlock(self):
        cmd = self.unlock_combo.currentText().strip()
        if not cmd:
            return
        # frame it like the other commands ("$" + JSON) and send
        self.server.send(self.server._frame(cmd), "unlock-try")
        self.status.setText("Unlock sent — watch the log for the reply")

    def toggle_mute(self):
        self._muted = not getattr(self, "_muted", False)
        self.mic.set_muted(self._muted)
        self.mute_btn.setText("🔊 Unmute" if self._muted else "🔇 Mute")
        self.log(f"[AUDIO] mic {'MUTED' if self._muted else 'live'}")

    def try_talk(self):
        cmd = self.talk_combo.currentText().strip()
        if cmd:
            self.server.send_talk(cmd)
            self.log(f"[TRY] talk cmd: {cmd}")

    def reject_call(self):
        self.server.hangup()
        self._teardown()
        self.reject_btn.setEnabled(True)   # keep End active so a stuck call can be re-cut
        self.status.setText("Call ended")

    def on_remote_hangup(self):
        self._teardown()
        self.status.setText("Remote hung up")

    def on_closed(self):
        self._teardown()
        self.status.setText("Waiting for intercom call…")

    def _teardown(self):
        self._stop_ring()
        self.server.ringing = False
        self.self_timer.stop()
        self.mic.stop()
        self.decoder.stop_decoder()
        self.video.setText("DOOR CAMERA")
        self.video.setPixmap(QPixmap())
        self.answer_btn.setEnabled(False)
        self.unlock_btn.setEnabled(False)
        self.reject_btn.setEnabled(False)

    def closeEvent(self, e):
        self.discovery.stop()
        self.server.stop()
        self._teardown()
        if self.self_cam:
            self.self_cam.release()
        super().closeEvent(e)


def main():
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()