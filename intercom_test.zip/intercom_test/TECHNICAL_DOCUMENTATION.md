# Smart Indoor Intercom — Technical & Integration Documentation

This document describes the reverse-engineered intercom protocol and the
reference Python client (`intercom_app.py`) in enough detail for your app
developers to re-implement the same behaviour inside a production smart-home
application on any platform.

It has three parts:

1. **System overview & architecture** — what the system does and how the pieces fit.
2. **Protocol specification** — the on-the-wire format, the authoritative reference for integration.
3. **Code walkthrough** — every class and method in the reference client, explained.

A short integration checklist and a list of known limitations close the document.

---

## 1. System overview & architecture

The device under integration is a **Tuya-based IP video door station** ("the door"). It
calls an **indoor station** ("the client") over the local network, streams H.264 video and
G.711 audio, accepts two-way voice, and exposes a door-release command. The reference client
turns a laptop (or any host) into a software indoor station.

There is no cloud and no vendor SDK involved in the call path. Everything happens directly
between the door and the client over the LAN, using a compact custom protocol. (The door also
emits unrelated Tuya cloud/discovery broadcasts on UDP 6667; those are not part of the call and
are ignored by this client.)

The call path uses two sockets:

- **UDP 8089 — discovery.** The door periodically asks "who is on the network and can take a
  call?" The client answers with a small JSON identity record so the door knows an indoor
  station exists at its IP.
- **TCP 8189 — the call.** The door opens a TCP connection to the client and multiplexes three
  kinds of framed messages over it: control commands (JSON), video (H.264), and audio (G.711).

```
            UDP 8089 (discovery)
   DOOR  ───────────────────────────►  CLIENT
   .138    "cmd_send_get_device_info"     (replies with SCREEN_INFO)

            TCP 8189 (the call, one connection, three multiplexed streams)
   DOOR  ──────────────────────────────────────────────►  CLIENT
          AA…  control  {"command":"Call"} / GetCallInfo / HangUp
          BB…  video    H.264 Annex-B elementary stream
          CC…  audio    G.711 A-law, 160 bytes / 20 ms
   DOOR  ◄──────────────────────────────────────────────  CLIENT
          AA…  control  Answer / StartTalk / HangUp / (unlock)
          CC…  audio    G.711 A-law (microphone uplink)
```

The reference client is built on **PySide6** (Qt) for the UI, **ffmpeg** (subprocess) for H.264
decoding, **sounddevice** for microphone/speaker, and the Python standard library plus
**audioop** for G.711 companding. None of these are required for your own implementation — they
are simply what the reference uses. The protocol is what matters.

---

## 2. Protocol specification

This is the authoritative reference for re-implementation.

### 2.1 Discovery (UDP 8089)

The client binds UDP port 8089 on all interfaces. When a datagram arrives whose text contains
either `cmd_send_get_call_device` or `cmd_send_get_device_info`, the client replies — to the
sender's IP, **port 8089** (not the datagram's source port) — with a compact JSON identity
record, the `SCREEN_INFO`:

```json
{
  "command": "cmd_reply_get_device_info",
  "appid": "7551000",
  "alias": "Laptop Indoor",
  "group_ip": "239.255.74.199",
  "serial": "LAPTOP001",
  "dstType": 3,
  "dstAddr": "999-000-1",
  "verify": 0,
  "deviceBusy": 0,
  "camera_en": 0,
  "relay0_delay": 1
}
```

Field notes for integrators:

- `appid`, `dstType`, `verify` — device-class identifiers; keep the captured values unless your
  installation differs.
- `dstAddr` (`"999-000-1"`) — the address/extension the door uses to identify this indoor unit.
  In a multi-unit building each indoor station has a distinct `dstAddr`.
- `group_ip` — a multicast address the device family can use for group audio. **This client does
  not use multicast**; all media in observed calls travels over the TCP connection.
- `deviceBusy` — advertise `1` to make the door treat the unit as unavailable.
- `camera_en` — `0` here because the client sends no video upstream (video is one-way,
  door → client).
- `relay0_delay` — relates to the door's lock relay (see unlock, below).

Discovery repeats every few seconds throughout idle and during calls; the client must keep
answering or the door may consider the unit gone.

### 2.2 Frame format (TCP 8189)

Every message on the TCP connection — in both directions — uses the same envelope:

```
+--------------+---------------------+------------------+
| 4 bytes      | 4 bytes             | <length> bytes   |
| magic header | length (LE uint32)  | payload          |
+--------------+---------------------+------------------+
```

- The **length** is the payload size only (it excludes the 8-byte header) and is **little-endian**.
- The **magic header** selects the channel:

| Magic (hex) | Channel | Payload |
|-------------|---------|---------|
| `AA AA AA AA` | Control | UTF-8 JSON command |
| `BB BB BB BB` | Video   | H.264 Annex-B bytes |
| `CC CC CC CC` | Audio   | G.711 A-law, 160 bytes per frame |

Because TCP is a byte stream, a single read may contain several frames, a partial frame, or a
frame split across reads. A correct parser accumulates bytes, and only consumes a frame once all
8 + length bytes are present. If the buffer ever starts with bytes that are not one of the three
magics (desync), scan forward to the next known magic and resume.

A worked example from a real capture — the very first control frame:

```
aa aa aa aa | 12 00 00 00 | 7b 22 63 6f 6d 6d 61 6e 64 22 3a 22 43 61 6c 6c 22 7d
  magic         len = 0x12 = 18        {"command":"Call"}  (18 bytes)
```

### 2.3 Control commands (`AA AA AA AA`)

Payload is a JSON object with a `command` key. Observed commands:

**Door → client (incoming):**

| Command | Meaning |
|---------|---------|
| `{"command":"Call"}` | Door is ringing this unit. Start showing video; alert the user. |
| `{"command":"GetCallInfo"}` | Door asks the unit to confirm/identify during ring. |
| `{"command":"HangUp", …}` | Door ended the call. Tear down. |

**Client → door (outgoing):**

| Command | Meaning |
|---------|---------|
| `{"command":"Answer"}` | Accept the call. The client sends three accept variants for compatibility: `{"command":"Answer"}`, `{"command":"Answer","OtherAnswer":1}`, `{"command":"Answer","OtherAnswer":true}`. |
| `{"command":"StartTalk"}` | **Opens the door's speaker for the uplink.** Until this is sent, the door ignores the client's audio. Send it shortly after Answer. |
| `{"command":"HangUp","OtherAnswer":0}` | Reject or end the call. After sending, close the socket. |

**Door release (unlock) — not yet confirmed.** The door clearly supports a lock relay
(`relay0_delay` in `SCREEN_INFO`), but the exact unlock command was not captured. The client
ships a list of plausible candidates (`OpenDoor`, `Unlock`, `OpenLock`, `cmd_open_door`, …) that
an operator can try while watching the log for the door's reply. **To finalize this for
production, capture the command the original indoor panel sends when its unlock button is
pressed** (same framing, `AA AA AA AA` channel) and hard-code it.

### 2.4 Video (`BB BB BB BB`)

Each video frame's payload is raw **H.264 Annex-B** — NAL units prefixed with the `00 00 00 01`
start code. The stream contains standard SPS (`0x67`), PPS (`0x68`), IDR (`0x65`) and non-IDR
(`0x41`) NALs. SPS/PPS recur periodically, so a decoder that joins mid-stream synchronizes at the
next keyframe (typically within a second or two).

To decode, strip the 8-byte envelope and feed only the payload bytes to any H.264 decoder. **Do
not** feed the envelope/magic bytes — they corrupt the elementary stream.

The door begins streaming video during ringing, before Answer. The client takes advantage of this
to show a live preview while the call is still ringing.

### 2.5 Audio (`CC CC CC CC`)

Each audio frame's payload is **G.711 A-law**, **160 bytes**, representing **20 ms of 8 kHz mono**
audio (8000 samples/s × 0.02 s = 160 samples, one byte each). This format is used in **both**
directions and requires **no byte inversion** (an inverted variant was tested and rejected).

Playback: A-law → 16-bit PCM → speaker at 8 kHz.
Uplink: capture mic at 8 kHz mono 16-bit → 16-bit PCM → A-law → wrap in `CC CC CC CC` + length →
send on the call socket. Remember the uplink only plays at the door **after `StartTalk`** is sent.

The companding curve was identified from the idle/silence byte in the capture: G.711 A-law
silence is `0xD5`, which matched the captured stream (µ-law silence would be `0xFF`).

### 2.6 Call sequence (state machine)

```
IDLE
  └─ door sends Call ──────────────► RINGING
                                      • client shows video preview
                                      • user is alerted
RINGING
  ├─ user Accepts ─────────────────► CONNECTING
  │     • client → Answer (×3 variants)
  │     • client → StartTalk           (opens door speaker)
  │     • call_active = true
  │     • audio flows both ways (CC frames)
  ├─ user Rejects / door HangUp ───► IDLE  (client → HangUp, close socket)
CONNECTED
  ├─ door GetCallInfo ─────────────► client re-sends Answer
  ├─ user Unlock ──────────────────► client → <unlock command>  (TBD)
  └─ End / HangUp (either side) ───► IDLE  (close socket, stop media)
```

---

## 3. Code walkthrough (`intercom_app.py`)

The reference client is organized into four Qt components plus a window. Qt **signals** carry
data across threads safely (network/decoder threads emit; the UI thread receives).

### 3.1 Configuration block (top of file)

Defines the two ports, the ffmpeg path (auto-detected, with a Windows fallback), the display
resolution, the `SCREEN_INFO` identity record, and the lists of unlock/talk command candidates
used by the UI. *Vestigial:* `AUDIO_UPLINK_HOST/PORT/RATE` and `SELF_CAM_INDEX` are leftovers from
earlier iterations and are no longer used; they can be deleted. The `import audioop` requires the
`audioop-lts` package on Python 3.13+ (the module was removed from the stdlib there).

### 3.2 `DiscoveryListener(QObject)`

Owns the UDP 8089 socket on a background thread. On each datagram it checks for the discovery
keywords and replies with `SCREEN_INFO` to the sender at port 8089. Emits `log` strings for the UI
panel. This is what makes the door aware the unit exists.

### 3.3 `VideoDecoder(QThread)`

Wraps an `ffmpeg` subprocess used purely as a decoder: it accepts the raw H.264 elementary stream
on stdin and emits decoded `rgb24` frames on stdout, scaled to `VIDEO_W × VIDEO_H`.

- `start_decoder()` launches ffmpeg with `-flags low_delay` (note: **not** `-fflags nobuffer`,
  which breaks piped H.264). Idempotent — calling it twice is safe.
- `feed(data)` writes payload bytes to ffmpeg's stdin under a lock (called from the network
  thread).
- `run()` continuously reads exactly one frame's worth of bytes (`W×H×3`) from ffmpeg's stdout,
  wraps it in a `QImage`, and emits `frame`.
- `stop_decoder()` kills ffmpeg and joins the thread.

For a production app you would typically replace ffmpeg with the platform's native H.264 decoder
(MediaCodec on Android, VideoToolbox on iOS/macOS, Media Foundation on Windows) fed the same
payload bytes.

### 3.4 `CallServer(QObject)` — the protocol core

This is the most important class to port; it contains all protocol knowledge.

- `_serve()` binds TCP 8189 and accepts connections, each handled on its own thread.
- `_handle(conn, addr)` reads the socket in a loop, appends to a buffer, and calls `_parse()`.
  Resets per-connection state and emits `closed` on disconnect.
- `_parse(buf)` implements the framing from §2.2: reads magic + little-endian length, waits for a
  whole frame, then dispatches by channel — control to `_on_control`, audio to the `audio` signal
  (when `call_active`), video to the `video` signal (when `call_active` **or** `ringing`, which is
  what enables the pre-answer preview). Returns the unconsumed remainder.
- `_resync(buf)` recovers from desync by scanning to the next known magic.
- `_on_control(payload)` parses JSON commands: `Call` sets `ringing` and emits `incoming`;
  `HangUp` emits `remote_hangup`; `GetCallInfo` re-sends `Answer` while connected.
- `_frame(json_str)` builds a control frame (`AA AA AA AA` + length + JSON). `send()` transmits any
  prebuilt bytes and logs the size.
- `answer()` sends the three Answer variants, marks `call_active`, resets the audio counter.
- `send_audio(alaw_bytes)` wraps a 160-byte A-law frame in the `CC CC CC CC` envelope and sends it;
  logs roughly once per second.
- `send_talk(json_str)` sends a talk/`StartTalk` command. `hangup()` sends HangUp then closes the
  socket cleanly.

### 3.5 `AudioWorker(QThread)` — full-duplex audio

Runs the speaker and microphone together.

- `play(alaw)` (called from the network thread via the `audio` signal) decodes incoming A-law to
  PCM and appends it to a playback buffer, **capped** at `MAX_PLAY` bytes so latency can't build up
  (old audio is dropped rather than queued).
- `run()` opens an output stream whose callback drains the playback buffer (filling with silence on
  underrun), and an input stream that reads the mic in 160-sample blocks. For each mic block it
  computes a level for the meter, applies a **noise gate** (`rms < GATE` → send silence, which
  suppresses room noise and feedback when you're not speaking), applies **gain** with hard
  **clipping** (`GAIN`, `np.clip`), encodes to A-law, and sends it.
- `set_muted()` / `stop()` control the worker. `GAIN`, `GATE`, `MAX_PLAY` are the tuning knobs.

Re-implementation note: this is plain capture/playback with gain, gate and a jitter cap. It has
**no acoustic echo cancellation**; a production app on a speakerphone-style device should use the
platform's AEC (e.g. `VOICE_COMMUNICATION` mode on Android, `AVAudioSession` voice-chat mode on
iOS) for hands-free clarity.

### 3.6 `MainWindow(QMainWindow)` — UI and wiring

Builds the window (video pane, mic meter, unlock/talk selectors, Accept/Unlock/Mute/End buttons,
log panel) and wires the workers together with Qt signals. Key handlers:

- `on_incoming(ip)` — alert the user, enable Accept/End, and **start the decoder immediately** so
  video shows during ring.
- `accept_call()` — `answer()`, start mic, enable Unlock. (In production, also auto-send
  `StartTalk` here so the uplink opens without a manual button.)
- `unlock()` / `try_talk()` — send the selected command and log the reply.
- `toggle_mute()` — flips the mic between live and silent.
- `reject_call()` / `on_remote_hangup()` / `on_closed()` → `_teardown()` — stop media, clear the
  video, reset buttons, clear the `ringing` flag.

The self-view webcam is disabled (`self_cam = None`) because video is one-way; the self-view
widget is hidden.

---

## 4. Integration checklist (for the smart-home app)

The minimum to embed this into a production app:

1. **Identity / discovery.** Bind UDP 8089 (or your platform's equivalent), answer discovery with a
   per-unit `SCREEN_INFO`. Assign each indoor unit a unique `dstAddr`.
2. **Call socket.** Listen on TCP 8189; implement the length-prefixed framing parser exactly as in
   §2.2, dispatching by magic.
3. **Ring UX.** On `Call`, surface a full-screen incoming-call view and start the video preview from
   the `BB` stream immediately.
4. **Accept.** Send the three `Answer` variants, then `StartTalk`. Mark the call active so audio
   frames flow.
5. **Video.** Strip the envelope; feed payloads to a native H.264 decoder.
6. **Audio.** Decode `CC` payloads as G.711 A-law @ 8 kHz for playback; encode mic the same way for
   uplink; enable platform AEC.
7. **Unlock.** Capture the real unlock command from the OEM panel and wire it to your door-release
   button.
8. **End.** Send `HangUp` and close the socket; tear down media.

---

## 5. Known limitations & production notes

- **Unlock command unconfirmed.** Must be captured from the OEM panel before shipping door release.
- **No echo cancellation.** Hands-free audio will echo without platform AEC; the reference relies on
  gate + mute + a headset.
- **Telephone-grade audio.** G.711 @ 8 kHz is narrowband by design; it will not sound wideband.
- **No authentication or encryption.** The protocol is plaintext on the LAN with no auth. Treat the
  segment as trusted, or tunnel/segment it; do not expose ports 8089/8189 to the internet.
- **`audioop` dependency.** Removed from CPython 3.13+; install `audioop-lts`, or implement A-law in
  code, or use a platform codec.
- **Single call at a time.** The reference handles one active connection; a busy unit should
  advertise `deviceBusy: 1` and reject overlapping calls.
- **Multicast unused.** `group_ip` suggests a group-audio mode that this client does not implement;
  unicast-over-TCP was sufficient in all captures.
